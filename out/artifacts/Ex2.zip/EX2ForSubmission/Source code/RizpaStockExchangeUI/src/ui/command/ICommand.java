package ui.command;

public interface ICommand {
    void execute();
}
